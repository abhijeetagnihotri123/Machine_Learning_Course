1. This is the readme file of the assignment.
2. We have used Harris corner detector for the assignment due to some issues in SIFT inbuilt code in my device.
3. The confusion matrix for one of the thresold parameters is.
    [[ 482  498]
    [64 8956]].

Here we used SVM in binary classification of 0 and other digits because SVM is a binary classification.

4. The accuracies are as follows depending upon the k_size parameter.
    0.06->0.944
    0.05->0.952
    0.04->0.956